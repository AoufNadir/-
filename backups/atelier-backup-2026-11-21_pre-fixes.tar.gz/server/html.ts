import fs from 'fs';
import path from 'path';
import { getStore } from './store.ts';

const PUBLIC_ATELIER = path.resolve(process.cwd(), 'public', 'atelier');
const BUILD_TAG = '20261121';

function readTemplate(fileName: string): string {
  return fs.readFileSync(path.join(PUBLIC_ATELIER, fileName), 'utf-8');
}

export function renderAtelierAppHtml(): string {
  const tpl = readTemplate('atelier.html');
  return tpl
    .replace(/\{\{\s*build\s*\}\}/g, BUILD_TAG)
    .replace(/\{\{\s*csrf_token\s*\}\}/g, 'atelier-local-csrf');
}

export function renderAtelierLoginHtml(): string {
  const s = getStore();
  const tpl = readTemplate('atelier-login.html');
  return tpl.replace(/\{\{\s*workshop\s*\}\}/g, s.profile.name_ar || 'مطبعة رقمي');
}
