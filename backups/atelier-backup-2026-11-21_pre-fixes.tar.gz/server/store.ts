import fs from 'fs';
import path from 'path';
import { createSeedData } from './seed.ts';
import { AppRole, OrderRecord, StoreData, UserAccount } from './types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_PATH = path.join(DATA_DIR, 'atelier-store.json');
export const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

export class AtelierError extends Error {
  status: number;
  errors?: Record<string, string>;
  constructor(message: string, status = 417, errors?: Record<string, string>) {
    super(message);
    this.status = status;
    this.errors = errors;
  }
}

let cached: StoreData | null = null;

export function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export function getStore(): StoreData {
  if (cached) return cached;
  ensureDirs();
  if (fs.existsSync(STORE_PATH)) {
    try {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      cached = JSON.parse(raw) as StoreData;
      return cached;
    } catch {
      // fall through to seed
    }
  }
  cached = createSeedData();
  saveStore();
  return cached;
}

export function saveStore() {
  if (!cached) return;
  ensureDirs();
  fs.writeFileSync(STORE_PATH, JSON.stringify(cached, null, 2), 'utf-8');
}

export function resetStore(): StoreData {
  cached = createSeedData();
  saveStore();
  return cached;
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function nowDateTime(): string {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

export function addDays(isoStr: string, n: number): string {
  const d = new Date(isoStr.slice(0, 10) + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function daysBetween(a: string, b: string): number {
  const da = new Date(a.slice(0, 10) + 'T00:00:00Z').getTime();
  const db = new Date(b.slice(0, 10) + 'T00:00:00Z').getTime();
  return Math.round((db - da) / 86400000);
}

export function nextId(prefix: string): string {
  const s = getStore();
  const n = (s.seq[prefix] || 0) + 1;
  s.seq[prefix] = n;
  const yr = new Date().getFullYear();
  if (['SO', 'SI', 'DN', 'PE', 'PI', 'PO', 'JE', 'STE', 'QTN'].includes(prefix)) {
    return `${prefix}-${yr}-${String(n).padStart(4, '0')}`;
  }
  return `${prefix}-${String(n).padStart(3, '0')}`;
}

export function parseJsonArg<T = any>(val: any, fallback: T): T {
  if (val === undefined || val === null || val === '') return fallback;
  if (typeof val === 'string') {
    try {
      return JSON.parse(val) as T;
    } catch {
      return fallback;
    }
  }
  return val as T;
}

export function num(val: any, fallback = 0): number {
  const n = Number(val);
  return Number.isFinite(n) ? n : fallback;
}

export function round2(val: number): number {
  const r = Math.round((Number(val) || 0) * 100) / 100;
  return r === 0 ? 0 : r;
}

export function getUserByEmail(email?: string | null): UserAccount {
  const s = getStore();
  if (email) {
    const found = s.users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.enabled);
    if (found) return found;
  }
  return s.users.find((u) => u.role === 'manager' && u.enabled) || s.users[0];
}

export function isWorkerRole(role: AppRole): boolean {
  return role === 'designer' || role === 'production';
}

export function getPermissions(role: AppRole) {
  const worker = isWorkerRole(role);
  const manager = role === 'manager';
  const sales = role === 'sales';
  const accountant = role === 'accountant';
  return {
    order: (manager || sales) && !worker,
    customer: (manager || sales || accountant) && !worker,
    prices: manager,
    payment: (manager || sales || accountant) && !worker,
    box: sales && !worker,
    deliver: manager || sales,
    expense: manager || accountant,
    finance: manager || accountant,
    cost: manager || accountant,
    stock: role !== 'designer',
  };
}

export function getMemberName(userEmail: string): string | null {
  const s = getStore();
  const m = s.team.find((x) => x.user === userEmail);
  return m ? m.name : null;
}

export function getFullName(email: string): string {
  const s = getStore();
  const u = s.users.find((x) => x.email === email);
  return u ? u.full_name : email;
}

export function computeFundBalance(account: string): number {
  const s = getStore();
  let bal = 0;
  for (const op of s.openings) {
    if (!op.reversed && op.kind === 'fund' && op.target === account) bal += op.amount;
  }
  for (const p of s.payments) {
    if (p.account !== account) continue;
    // Uncleared cheques aren't in bank balance yet or are tracked separately? Keep them in balance once cleared or non-cheque
    if (p.mode_of_payment === 'Cheque' && !p.clearance_date) continue;
    if (p.payment_type === 'Receive') bal += p.amount;
    else bal -= p.amount;
  }
  for (const e of s.expenses) {
    if (e.paid_from === account) bal -= e.amount;
  }
  for (const t of s.transfers) {
    if (t.from_account === account) bal -= t.amount;
    if (t.to_account === account) bal += t.amount;
  }
  for (const om of s.owner_moves) {
    if (om.account !== account) continue;
    if (om.kind === 'in') bal += om.amount;
    else bal -= om.amount;
  }
  for (const h of s.handovers) {
    if (h.status !== 'confirmed') continue;
    if (h.account === account) bal -= h.recorded;
    if (account === 'CASH-MAIN') bal += h.counted;
  }
  return round2(bal);
}

export function computeOrderPaid(orderName: string): number {
  const s = getStore();
  let total = 0;
  for (const p of s.payments) {
    if (p.party_type === 'Customer' && p.sales_order === orderName) {
      if (p.payment_type === 'Receive') total += p.amount;
      else total -= p.amount;
    }
  }
  return round2(Math.max(0, total));
}

export function syncOrderTotals(order: OrderRecord) {
  const hasPending = order.lines.some((l) => l.price_pending || l.rate === null || l.rate === undefined);
  order.price_pending = hasPending ? 1 : 0;
  let net = 0;
  for (const l of order.lines) {
    if (l.rate !== null && l.rate !== undefined && !l.price_pending) {
      l.amount = round2(num(l.qty) * num(l.rate));
      net += l.amount;
    } else {
      l.amount = null;
    }
  }
  const s = getStore();
  const cust = s.customers.find((c) => c.name === order.customer);
  const tvaOn = s.docs.tva && !(cust?.tva_exempt);
  const grand = tvaOn ? round2(net * (1 + (s.docs.tva_rate || 19) / 100)) : round2(net);
  order.net_total = round2(net);
  order.grand_total = hasPending ? 0 : grand;
  order.paid = computeOrderPaid(order.name);
}

export function computeCustomerBalance(customerName: string): {
  balance: number;
  invoiced: number;
  received: number;
  outstanding: number;
  unbilled: number;
  invoices: number;
} {
  const s = getStore();
  const cust = s.customers.find((c) => c.name === customerName);
  const opening = cust?.opening_balance || 0;
  const openExtra = s.openings
    .filter((o) => !o.reversed && o.kind === 'Customer' && o.target === customerName)
    .reduce((a, b) => a + b.amount, 0);

  let invoiced = 0;
  let unbilled = 0;
  let unbilledGross = 0;
  let received = 0;

  for (const o of s.orders) {
    if (o.customer !== customerName || o.docstatus === 2) continue;
    if (o.per_billed >= 100) {
      invoiced += o.grand_total;
    } else if (!o.price_pending) {
      unbilled += Math.max(0, o.grand_total - o.paid);
      unbilledGross += o.grand_total;
    }
  }
  for (const p of s.payments) {
    if (p.party_type === 'Customer' && p.party === customerName) {
      if (p.payment_type === 'Receive') received += p.amount;
      else received -= p.amount;
    }
  }

  const ledgerBalance = round2(opening + openExtra + invoiced - received);
  const totalBalance = round2(ledgerBalance + unbilledGross);
  const invoicesDue = round2(totalBalance - unbilled);
  return {
    balance: Math.max(0, totalBalance),
    invoiced: round2(invoiced),
    received: round2(received),
    outstanding: Math.max(0, round2(invoiced + opening + openExtra - received)),
    unbilled: round2(unbilled),
    invoices: Math.max(0, invoicesDue),
  };
}

export function getPeriodBounds(period = 'month', start?: string, end?: string): [string, string, string, string] {
  const now = new Date();
  let a: Date;
  let b: Date;
  if (period === 'custom' && start && end) {
    a = new Date(start + 'T00:00:00Z');
    b = new Date(end + 'T00:00:00Z');
  } else if (period === 'week') {
    b = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    a = new Date(b);
    a.setUTCDate(a.getUTCDate() - 6);
  } else if (period === 'quarter') {
    const qm = Math.floor(now.getUTCMonth() / 3) * 3;
    a = new Date(Date.UTC(now.getUTCFullYear(), qm, 1));
    b = new Date(Date.UTC(now.getUTCFullYear(), qm + 3, 0));
  } else if (period === 'year') {
    a = new Date(Date.UTC(now.getUTCFullYear(), 0, 1));
    b = new Date(Date.UTC(now.getUTCFullYear(), 11, 31));
  } else {
    a = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
    b = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 0));
  }
  const spanDays = Math.max(1, Math.round((b.getTime() - a.getTime()) / 86400000) + 1);
  const pb = new Date(a.getTime() - 86400000);
  const pa = new Date(pb.getTime() - (spanDays - 1) * 86400000);
  return [
    a.toISOString().slice(0, 10),
    b.toISOString().slice(0, 10),
    pa.toISOString().slice(0, 10),
    pb.toISOString().slice(0, 10),
  ];
}

export function addCardLog(orderName: string, content: string, owner: string, type: 'Info' | 'Comment' = 'Info') {
  const s = getStore();
  s.comments.unshift({
    name: nextId('CMT'),
    reference_doctype: 'Sales Order',
    reference_name: orderName,
    comment_type: type,
    content,
    owner,
    creation: nowDateTime(),
  });
}

export function notifyMember(memberName: string, orderName: string, text: string) {
  const s = getStore();
  const m = s.team.find((x) => x.name === memberName);
  if (!m?.user) return;
  s.notifications.unshift({
    id: `NT-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    user: m.user,
    order: orderName,
    text,
    at: nowDateTime(),
    read: 0,
  });
}
