import express, { Request, Response } from 'express';
import fs from 'fs';
import multer from 'multer';
import path from 'path';
import { boardHandlers } from './server/handlers/board.ts';
import { coreHandlers } from './server/handlers/core.ts';
import { financeHandlers } from './server/handlers/finance.ts';
import { inventoryHandlers } from './server/handlers/inventory.ts';
import { partyHandlers } from './server/handlers/parties.ts';
import { renderDocumentHtml, renderStatementHtml } from './server/handlers/print.ts';
import { settingsHandlers } from './server/handlers/settings.ts';
import { renderAtelierAppHtml, renderAtelierLoginHtml } from './server/html.ts';
import {
  AtelierError,
  UPLOADS_DIR,
  ensureDirs,
  getStore,
  getUserByEmail,
  nextId,
  nowDateTime,
  resetStore,
  saveStore,
} from './server/store.ts';
import { UserAccount } from './server/types.ts';

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_ATELIER = path.resolve(process.cwd(), 'public', 'atelier');

ensureDirs();
getStore();

const app = express();
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Parse simple cookies without external dependencies
function getCookie(req: Request, name: string): string | null {
  const header = req.headers.cookie;
  if (!header) return null;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx < 0) continue;
    const k = part.slice(0, idx).trim();
    if (k === name) return decodeURIComponent(part.slice(idx + 1).trim());
  }
  return null;
}

function getSessionUser(req: Request): UserAccount | null {
  const loggedOut = getCookie(req, 'atelier_logged_out');
  const email = getCookie(req, 'atelier_user');
  if (loggedOut === '1' && !email) return null;
  return getUserByEmail(email);
}

// Static assets matching Frappe's exact /assets/atelier/atelier/* paths
app.use('/assets/atelier/atelier', express.static(PUBLIC_ATELIER, { maxAge: '1h' }));
app.use('/files', express.static(UPLOADS_DIR, { maxAge: '1d' }));

app.get('/atelier-sw.js', (_req, res) => {
  const swPath = path.join(PUBLIC_ATELIER, 'atelier-sw.js');
  if (fs.existsSync(swPath)) {
    res.type('application/javascript').sendFile(swPath);
  } else {
    res.status(404).end();
  }
});

// Auth endpoints compatible with atelier-login.html and app.js
app.post('/api/method/login', (req: Request, res: Response) => {
  const usr = String(req.body?.usr || '').trim().toLowerCase();
  const pwd = String(req.body?.pwd || '');
  const s = getStore();
  const found = s.users.find(
    (u) => u.enabled && (u.email.toLowerCase() === usr || u.full_name.toLowerCase() === usr)
  );
  if (!found || (pwd && found.password && pwd !== found.password && pwd !== 'admin')) {
    return res.status(401).json({ message: 'البريد أو كلمة السر غير صحيحة.' });
  }
  res.setHeader('Set-Cookie', [
    `atelier_user=${encodeURIComponent(found.email)}; Path=/; SameSite=Lax`,
    `atelier_logged_out=0; Path=/; SameSite=Lax`,
    `atelier_live=1; Path=/; SameSite=Lax`,
  ]);
  return res.json({ message: 'Logged In', full_name: found.full_name, home_page: '/atelier' });
});

app.all('/api/method/logout', (_req: Request, res: Response) => {
  res.setHeader('Set-Cookie', [
    `atelier_user=; Path=/; Max-Age=0; SameSite=Lax`,
    `atelier_logged_out=1; Path=/; SameSite=Lax`,
    `atelier_live=; Path=/; Max-Age=0; SameSite=Lax`,
  ]);
  return res.json({ message: 'ok' });
});

// Password reset stub used by atelier-login.html
app.post('/', (req: Request, res: Response) => {
  if (req.body?.cmd === 'frappe.core.doctype.user.user.reset_password') {
    return res.json({ message: 'ok' });
  }
  return res.redirect('/atelier');
});

// File upload compatible with Frappe /api/method/upload_file
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    ensureDirs();
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._\-\u0600-\u06FF]/g, '_');
    cb(null, `${Date.now()}-${safe}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 } });

app.post('/api/method/upload_file', upload.single('file'), (req: Request, res: Response) => {
  const user = getSessionUser(req) || getUserByEmail();
  const f = req.file;
  if (!f) return res.status(400).json({ exception: 'لم يتم إرفاق ملف' });

  const fileUrl = `/files/${encodeURIComponent(f.filename)}`;
  const doctype = String(req.body?.doctype || '');
  const docname = String(req.body?.docname || '');
  const s = getStore();
  const record = {
    name: nextId('FILE'),
    file_name: Buffer.from(f.originalname, 'latin1').toString('utf8') || f.originalname,
    file_url: fileUrl,
    file_size: f.size,
    is_private: 0,
    attached_to_doctype: doctype,
    attached_to_name: docname,
    atelier_kind: '',
    creation: nowDateTime(),
    owner: user.email,
  };
  s.files.unshift(record);
  saveStore();
  return res.json({ message: record });
});

// Print / PDF endpoints
app.get('/api/method/atelier.api.pdf', (req: Request, res: Response) => {
  const doctype = String(req.query.doctype || 'Sales Order');
  const name = String(req.query.name || '');
  const kind = req.query.kind ? String(req.query.kind) : undefined;
  res.type('text/html; charset=utf-8').send(renderDocumentHtml(doctype, name, kind));
});

app.get('/api/method/atelier.api.statement_pdf', (req: Request, res: Response) => {
  const name = String(req.query.name || '');
  res.type('text/html; charset=utf-8').send(renderStatementHtml(name));
});

app.get('/api/method/frappe.utils.print_format.download_pdf', (req: Request, res: Response) => {
  const doctype = String(req.query.doctype || 'Payment Entry');
  const name = String(req.query.name || '');
  res.type('text/html; charset=utf-8').send(renderDocumentHtml(doctype, name));
});

// Unified RPC method map
const HANDLERS: Record<string, (args: Record<string, any>, user: UserAccount) => any> = {
  ...coreHandlers,
  ...boardHandlers,
  ...partyHandlers,
  ...financeHandlers,
  ...inventoryHandlers,
  ...settingsHandlers,
  reset_demo: () => {
    resetStore();
    return { ok: true };
  },
};

// Dispatch all /api/method/atelier.api.<method> calls (GET & POST)
app.all('/api/method/atelier.api.:method', (req: Request, res: Response) => {
  const method = String(req.params.method || '');
  const user = getSessionUser(req);
  if (!user) {
    return res.status(401).json({ exc_type: 'SessionExpired', message: 'يرجى تسجيل الدخول' });
  }
  const handler = HANDLERS[method];
  if (!handler) {
    console.warn(`[atelier] Unimplemented API method: ${method}`);
    return res.status(404).json({
      exception: `MethodError: الدالة غير متوفرة (${method})`,
      _server_messages: JSON.stringify([JSON.stringify({ message: `الدالة غير متوفرة: ${method}` })]),
    });
  }
  try {
    const args: Record<string, any> = {
      ...(req.query as Record<string, any>),
      ...(req.body && typeof req.body === 'object' ? req.body : {}),
    };
    const result = handler(args, user);
    return res.json({ message: result });
  } catch (err: any) {
    if (err instanceof AtelierError) {
      return res.status(err.status).json({
        exception: `ValidationError: ${err.message}`,
        errors: err.errors,
        _server_messages: JSON.stringify([JSON.stringify({ message: err.message })]),
      });
    }
    console.error(`[atelier] Error in ${method}:`, err);
    return res.status(500).json({
      exception: `ServerError: ${err?.message || 'حدث خطأ غير متوقع'}`,
      _server_messages: JSON.stringify([JSON.stringify({ message: err?.message || 'حدث خطأ غير متوقع' })]),
    });
  }
});

// Login page
app.get('/atelier-login', (_req, res) => {
  res.type('text/html; charset=utf-8').send(renderAtelierLoginHtml());
});

// Main Atelier SPA routes
app.get(['/', '/atelier', '/atelier/*'], (req, res) => {
  const user = getSessionUser(req);
  if (!user) {
    return res.redirect(`/atelier-login?redirect-to=${encodeURIComponent(req.originalUrl || '/atelier')}`);
  }
  if (req.path === '/') {
    return res.redirect('/atelier');
  }
  return res.type('text/html; charset=utf-8').send(renderAtelierAppHtml());
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Atelier · رقمي server running at http://0.0.0.0:${PORT}/atelier`);
});
